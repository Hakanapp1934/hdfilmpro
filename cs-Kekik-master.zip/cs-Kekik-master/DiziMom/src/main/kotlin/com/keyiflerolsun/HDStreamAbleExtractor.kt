// ! Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

package com.keyiflerolsun

class HDStreamAble : PeaceMakerst() {
    override var name    = "HDStreamAble"
    override var mainUrl = "https://hdstreamable.com"
}