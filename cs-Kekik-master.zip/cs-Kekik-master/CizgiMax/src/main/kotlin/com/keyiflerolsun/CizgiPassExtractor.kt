// ! Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

package com.keyiflerolsun

class CizgiPass : CizgiDuo() {
    override var name    = "CizgiPass"
    override var mainUrl = "https://cizgipass5.online"
}