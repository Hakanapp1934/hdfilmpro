package com.keyiflerolsun

data class ChContent(
    val chName : String,
    val chUrl : String,
    val chImg : String,
    val chHeaders : String,
    val chReg : String,
    val chType: String
)